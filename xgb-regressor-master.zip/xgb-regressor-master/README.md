# MLflow XGBoost Regressor

This sample project trains a regression tree using [XGBoost](https://github.com/dmlc/xgboost) and makes it available as an [MLflow](http://mlflow.org) project.
